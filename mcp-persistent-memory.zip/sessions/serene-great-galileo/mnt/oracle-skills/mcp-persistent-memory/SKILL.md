---
name: mcp-persistent-memory
description: Build an MCP (Model Context Protocol) server that provides persistent cross-session memory for AI coding agents. Use when building shared memory that works across Claude Code, Codex, and any MCP-compatible client. Backed by SQLite with full-text search, zero external services required. Supports storing architectural decisions, project conventions, debugging insights, and codebase knowledge that persists across sessions and tools.
---

# MCP Persistent Memory Server

Build an MCP-compatible memory server that gives AI coding agents persistent recall across sessions. A single SQLite file acts as the shared brain — any MCP client (Claude Code, Codex, Claude Desktop) can store and retrieve memories through the standard MCP tool protocol.

## Prerequisites

- Node.js 18+ (LTS recommended)
- npm or yarn
- Any MCP-compatible client (Claude Code, Codex, Claude Desktop)

## Architecture

```
[Claude Code]  [Codex]  [Claude Desktop]  [Any MCP Client]
      |            |            |                |
      v            v            v                v
      +------------+------------+----------------+
                         |
                    MCP Protocol (stdio)
                         |
                         v
              [MCP Memory Server]
                    Node.js
                         |
                         v
              [SQLite Database]
              ~/.mcp-memory/memory.db
```

**Key design principles:**
- Single SQLite file, zero external services (no Redis, no Postgres)
- WASM-based SQLite (sql.js) — no native compilation, works everywhere
- Stdio transport — spawned by the MCP client, no ports to manage
- LIKE-based text search across key, content, and tags
- Automatic persistence — every write flushes to disk immediately
- Cross-tool sharing — all clients read/write the same DB file

## Project Structure

```
mcp-memory-server/
├── src/
│   ├── index.ts          # MCP server entry point, tool definitions
│   ├── db.ts             # SQLite database layer (CRUD operations)
│   └── sql.js.d.ts       # Type declarations for sql.js
├── dist/                  # Compiled output (after npm run build)
├── package.json
├── tsconfig.json
└── README.md
```

## Database Schema

Single table with automatic timestamps:

```sql
CREATE TABLE IF NOT EXISTS memories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  key        TEXT    NOT NULL UNIQUE,
  content    TEXT    NOT NULL,
  tags       TEXT    NOT NULL DEFAULT '',   -- comma-separated
  source     TEXT    NOT NULL DEFAULT 'unknown',
  created_at TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Indexes for fast filtering
CREATE INDEX idx_memories_source ON memories(source);
CREATE INDEX idx_memories_updated ON memories(updated_at);
```

The `key` column is unique — inserting with an existing key performs an upsert (update content, tags, source, updated_at).

## Database Layer

### Types

```typescript
interface Memory {
  id: number;
  key: string;
  content: string;
  tags: string;       // comma-separated
  source: string;     // e.g. "claude-code", "codex", "manual"
  created_at: string;
  updated_at: string;
}

interface MemoryInput {
  key: string;
  content: string;
  tags?: string[];
  source?: string;
}

interface RecallOptions {
  query?: string;      // free-text search
  tags?: string[];     // filter by tags (OR logic)
  source?: string;     // filter by source
  limit?: number;      // max results (default 20)
}
```

### Database Initialization

```typescript
import initSqlJs from "sql.js";
import fs from "fs";

async function getDb(): Promise<Database> {
  const SQL = await initSqlJs();
  const dbPath = process.env.MEMORY_DB_PATH
    ?? path.join(os.homedir(), ".mcp-memory", "memory.db");

  // Load existing DB or create new
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    return new SQL.Database(buffer);
  }
  return new SQL.Database();
}
```

### Persistence

Every write operation flushes to disk immediately:

```typescript
function saveToFile() {
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}
```

### CRUD Operations

**Remember (Upsert):**
```typescript
function remember(db, input: MemoryInput): Memory {
  const tags = (input.tags ?? []).join(",");
  db.run(`
    INSERT INTO memories (key, content, tags, source)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET
      content = excluded.content,
      tags = excluded.tags,
      source = excluded.source,
      updated_at = datetime('now')
  `, [input.key, input.content, tags, input.source ?? "unknown"]);
  saveToFile();
  return getByKey(db, input.key);
}
```

**Recall (Search):**
```typescript
function recall(db, opts: RecallOptions): Memory[] {
  if (opts.query) {
    // LIKE-based search across key, content, tags
    const term = `%${opts.query}%`;
    sql = "SELECT * FROM memories WHERE (key LIKE ? OR content LIKE ? OR tags LIKE ?)";
    params = [term, term, term];
  }
  if (opts.tags?.length) {
    // OR logic: match any tag
    const tagClauses = opts.tags.map(() => "tags LIKE ?");
    sql += ` AND (${tagClauses.join(" OR ")})`;
    params.push(...opts.tags.map(t => `%${t}%`));
  }
  if (opts.source) {
    sql += " AND source = ?";
    params.push(opts.source);
  }
  sql += " ORDER BY updated_at DESC LIMIT ?";
  params.push(opts.limit ?? 20);
  return db.prepare(sql).bind(params).all();
}
```

**Forget (Delete):**
```typescript
function forget(db, key: string): boolean {
  db.run("DELETE FROM memories WHERE key = ?", [key]);
  saveToFile();
  return db.getRowsModified() > 0;
}
```

## MCP Tool Definitions

Four tools exposed via the MCP protocol:

### remember

Store or update a memory with a unique key.

```typescript
server.tool("remember", "Store a memory with a unique key. If the key exists, it is updated.", {
  key: z.string().describe("Unique slug (e.g. 'project-stack', 'auth-flow-decision')"),
  content: z.string().describe("The memory content — be as detailed as useful"),
  tags: z.array(z.string()).optional().describe("Tags for categorization"),
  source: z.string().optional().describe("Which tool created this (e.g. 'claude-code', 'codex')"),
});
```

### recall

Search and retrieve memories by text query, tags, or source.

```typescript
server.tool("recall", "Search memories. Use at session start to load context.", {
  query: z.string().optional().describe("Free-text search across key, content, tags"),
  tags: z.array(z.string()).optional().describe("Filter by tags (OR logic)"),
  source: z.string().optional().describe("Filter by source"),
  limit: z.number().optional().default(20).describe("Max results"),
});
```

### forget

Delete a specific memory by key.

```typescript
server.tool("forget", "Delete a memory by key.", {
  key: z.string().describe("The key of the memory to delete"),
});
```

### list_memories

List all stored memories with pagination.

```typescript
server.tool("list_memories", "List all memories, most recently updated first.", {
  limit: z.number().optional().default(50),
  offset: z.number().optional().default(0),
});
```

## MCP Server Entry Point

```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const db = await getDb();
const server = new McpServer({ name: "memory", version: "1.0.0" });

// Register tools (remember, recall, forget, list_memories)
// ...

const transport = new StdioServerTransport();
await server.connect(transport);
```

## Installation

```bash
cd mcp-memory-server
npm install
npm run build
```

## Client Configuration

### Claude Code

```bash
claude mcp add --scope user memory node /absolute/path/to/mcp-memory-server/dist/index.js
```

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "memory": {
      "command": "node",
      "args": ["/absolute/path/to/mcp-memory-server/dist/index.js"]
    }
  }
}
```

### Codex

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.memory]
command = "node"
args = ["/absolute/path/to/mcp-memory-server/dist/index.js"]
```

## Seeding Project Knowledge

Scan a codebase and populate memory programmatically using the MCP client SDK:

```javascript
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

const transport = new StdioClientTransport({
  command: "node",
  args: ["/path/to/mcp-memory-server/dist/index.js"],
});
const client = new Client({ name: "seed-script", version: "1.0.0" }, { capabilities: {} });
await client.connect(transport);

await client.callTool({
  name: "remember",
  arguments: {
    key: "project-overview",
    content: "This project is a React + Flask app that...",
    tags: ["project", "overview"],
    source: "codebase-scan",
  },
});

await client.close();
```

### Recommended Memory Categories

When seeding a project, store memories for each of these:

| Key Pattern | What to Store |
|---|---|
| `{project}-overview` | What the project is, its purpose, codename |
| `{project}-tech-stack` | Languages, frameworks, versions, dependencies |
| `{project}-architecture` | System design, request flow, component hierarchy |
| `{project}-directory-structure` | Key files and what each one does |
| `{project}-api-endpoints` | Routes, auth flow, request/response formats |
| `{project}-config` | Environment variables, config files, feature flags |
| `{project}-deployment` | Docker, K8s, CI/CD, ports, secrets |
| `{project}-dev-commands` | How to run locally, test, build |
| `{project}-conventions` | Coding style, naming, patterns the team follows |
| `{project}-related-projects` | Sibling services, data flow between systems |

### Auto-Loading at Session Start

Add to your project's `CLAUDE.md` or `codex.md`:

```markdown
## Memory
At the start of each session, call `recall` with tags ["{project-name}"] to load
project context from persistent memory. When you learn something new about the
project (architectural decisions, debugging insights, conventions), call `remember`
to store it for future sessions.
```

## Key Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `MEMORY_DB_PATH` | `~/.mcp-memory/memory.db` | Custom path for the SQLite file |

## Common Usage Patterns

### Store a Decision

```
"Remember that we switched from in-memory sessions to Redis for multi-replica support"
→ Agent calls remember(key: "session-backend-decision", content: "...", tags: ["architecture"])
```

### Load Project Context

```
"Recall everything about odin-assistant"
→ Agent calls recall(tags: ["odin-assistant"])
```

### Search for Specific Knowledge

```
"What do we know about the auth flow?"
→ Agent calls recall(query: "auth")
```

### Clean Up Outdated Memory

```
"Forget the old deployment process — we switched to ArgoCD"
→ Agent calls forget(key: "deployment-process")
→ Agent calls remember(key: "deployment-process", content: "Using ArgoCD now...", tags: ["deployment"])
```

## Dependencies

```json
{
  "@modelcontextprotocol/sdk": "^1.12.1",
  "sql.js": "^1.12.0",
  "zod": "^3.24.0"
}
```

## Scaling Beyond Text Search

If you outgrow LIKE-based search (typically at thousands of memories or when you need semantic similarity), add an embeddings column:

```sql
ALTER TABLE memories ADD COLUMN embedding BLOB;
```

Then add a vector search path alongside existing text search:
1. Generate embeddings via a local model (Ollama) or API call on `remember`
2. On `recall`, compute query embedding and rank by cosine similarity
3. Fall back to text search when embeddings are unavailable

This keeps the server self-contained while enabling semantic recall like "what was that thing about session management" matching a memory keyed as "redis-migration-decision".
