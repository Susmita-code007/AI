# Code Review Workflow Checklist

## Before Reviewing
- [ ] Confirm repo instructions via applicable `AGENTS.md` files.
- [ ] Ensure local environment clean (`git status`).
- [ ] Fetch latest remote changes (`git fetch --all`).
- [ ] Checkout specified branch and confirm base branch.
- [ ] Skim PR description/spec for intent.
- [ ] Capture Jira ticket ID, summary, and acceptance criteria if provided.
- [ ] Cross-check PR title/description against the ticket, noting any scope gaps.
- [ ] Record required ticket validation steps (edge cases, acceptance tests).

## Diff Analysis
- [ ] Review overall diff stats (`git diff --stat`).
- [ ] Inspect commit history for context (`git log <base>..HEAD`).
- [ ] Walk through each file:
  - [ ] Understand functional impact.
  - [ ] Flag correctness/perf/security concerns.
  - [ ] Verify code style and conventions.
  - [ ] Look for missing tests or docs.
- [ ] Note any follow-up questions for author.

## Validation
- [ ] Identify required tests/build steps.
- [ ] Run targeted commands where feasible.
- [ ] Capture pass/fail results or blockers.

## Summarize Findings
- [ ] Decide approval stance (approve / changes / block).
- [ ] List high-severity findings with evidence.
- [ ] Highlight positive confirmations (optional but encouraging).
- [ ] Document validation performed and gaps/deferred checks.
- [ ] Provide actionable next steps for the author.
