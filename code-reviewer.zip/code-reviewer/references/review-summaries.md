# Review Summary Templates

## Template: Approve with Confidence
- **Decision:** Approve
- **Scope:** `<files / components touched>`
- **Jira alignment:** `<ticket ID, status, acceptance criteria satisfied>`
- **Key confirmations:**
  - `<Item 1>`
  - `<Item 2>`
- **Validation:** `<tests performed>`
- **Notes:** `<optional reminders or follow-up>`

## Template: Request Changes
- **Decision:** Changes requested
- **Blocking issues:**
  - `<Issue 1 – impact, file, suggested fix>`
  - `<Issue 2 – impact, file, suggested fix>`
- **Jira alignment:** `<acceptance criteria missed / ticket updates needed>`
- **Validation:** `<tests run or skipped>`
- **Next steps:** `<owner actions>`

## Template: Investigation Needed
- **Decision:** Defer / Investigate further
- **Risks / Unknowns:**
  - `<Risk 1>`
  - `<Risk 2>`
- **Evidence so far:** `<logs, diffs, observations>`
- **Jira follow-up:** `<questions for ticket owner or PM>`
- **Requested follow-up:** `<additional data or tests>`
