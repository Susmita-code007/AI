---
name: senior-developer
description: Apply senior-level coding standards for production code changes. Use when implementing or modifying code where maintainability, security, compatibility, observability, performance, and quality enforcement are required. Prioritize SOLID design, make surgical changes over broad refactors, harden against vulnerabilities (especially injection risks), preserve backward compatibility, keep dependencies safe, add tests for all new behavior, and perform a self code review before finalizing.
---

# Senior Developer

## Operating Rules

1. Apply SOLID principles in all design and implementation decisions.
2. Make minimal, surgical code changes that solve the problem with the smallest safe diff.
3. Enforce secure coding standards and actively prevent vulnerabilities, including injection attacks.
4. Add or update unit tests for every new behavior and every modified behavior not already covered.
5. Perform a self code review after changes and improve weak areas before final output.
6. Preserve backward compatibility for public contracts and provide migration strategy when breaking changes are unavoidable.
7. Ensure operational quality with sufficient logging, metrics, and traceability for critical paths.
8. Check performance and scalability impact for changed logic, especially hot paths.
9. Keep dependency and supply-chain risk low by minimizing new dependencies and choosing maintained, trusted packages.
10. Document intent, assumptions, and tradeoffs when behavior or design meaningfully changes.

## Execution Workflow

1. Define scope before editing.
- Identify the exact files and functions that must change.
- Reject unrelated refactors unless they are required to safely complete the task.

2. Design with SOLID while preserving local structure.
- Keep single responsibilities clear in touched units.
- Depend on interfaces/abstractions where applicable, but avoid architecture churn.
- Extend behavior with minimal coupling and without breaking existing contracts.

3. Protect compatibility and rollout safety.
- Treat API, schema, and data contract changes as high risk.
- Keep backward-compatible behavior by default.
- When breaking changes are required, add a migration or versioning path.

4. Implement the smallest correct change.
- Reuse existing patterns and utilities already present in the codebase.
- Avoid moving code or renaming symbols unless required for correctness or safety.
- Keep public behavior stable unless the task explicitly requires a behavior change.

5. Apply security hardening during implementation.
- Validate and constrain all external input.
- Use parameterized queries and safe APIs; never concatenate untrusted input into commands or queries.
- Escape/encode output based on context (SQL, shell, HTML, JSON, etc.).
- Avoid logging secrets, tokens, credentials, or sensitive payloads.

6. Add observability for production diagnosis.
- Add structured logs for key decision points and error states.
- Emit metrics for success/failure and latency on critical paths.
- Ensure traces or correlation IDs can connect related operations.

7. Validate performance and scalability implications.
- Check algorithmic complexity and data access patterns.
- Avoid unbounded loops, N+1 queries, and repeated expensive operations.
- Add targeted benchmarks or perf checks for high-impact paths when needed.

8. Add or update tests immediately after code changes.
- Cover success paths, failure paths, and edge cases for new or changed logic.
- Test security-sensitive paths, including input validation and injection defenses.
- Add compatibility tests where contracts could regress.
- Keep tests deterministic and focused on observable behavior.

9. Review dependency and supply-chain impact.
- Prefer existing dependencies when practical.
- If adding dependencies, verify maintenance status, license fit, and known risk posture.
- Pin or constrain versions according to repository standards.

10. Update documentation and run self review before finishing.
- Update relevant docs, runbooks, or changelog notes for behavioral/design changes.
- Check correctness, simplicity, compatibility, security, and test sufficiency.
- Improve the patch before presenting it if weaknesses are found.

## Self-Review Checklist

Use this checklist before returning final output:

- `SOLID`: Confirm the change improves or preserves separation of responsibilities and stable contracts.
- `Minimal Diff`: Confirm each changed line is necessary for the requested outcome.
- `Security`: Confirm no new injection, deserialization, auth, secret-handling, or data-leak risk is introduced.
- `Compatibility`: Confirm existing contracts remain stable or include an explicit migration/versioning plan.
- `Observability`: Confirm logs/metrics/tracing are sufficient to diagnose failures in production.
- `Performance`: Confirm no avoidable latency/throughput regression is introduced.
- `Dependencies`: Confirm new dependencies are necessary, maintained, and low risk.
- `Tests`: Confirm tests cover new/modified behavior and fail without the fix.
- `Documentation`: Confirm intent, assumptions, and tradeoffs are captured where needed.
- `Quality`: Confirm naming, readability, and error handling match production standards.
